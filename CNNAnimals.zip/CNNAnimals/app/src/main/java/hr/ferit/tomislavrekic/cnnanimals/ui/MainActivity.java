package hr.ferit.tomislavrekic.cnnanimals.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;

import hr.ferit.tomislavrekic.cnnanimals.R;
import hr.ferit.tomislavrekic.cnnanimals.presenter.NNPresenter;
import hr.ferit.tomislavrekic.cnnanimals.utils.Constants;
import hr.ferit.tomislavrekic.cnnanimals.utils.NNContract;

import static hr.ferit.tomislavrekic.cnnanimals.utils.Constants.REQUEST_TAKE_PHOTO;
import static hr.ferit.tomislavrekic.cnnanimals.utils.Constants.TAG;

public class MainActivity extends AppCompatActivity implements NNContract.View {

    private ImageView ivPreview;
    private TextView tvGuess;
    private Button btnSwitch;
    private NNContract.Presenter presenter;

    private Intent intentCamera;

    private static Context context;

    private BroadcastReceiver receiver;
    private IntentFilter filter;

    public static Context getContext(){
        return context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();

        presenter = new NNPresenter();
        presenter.addView(this);

        initViews();
        initIntents();

        configureReceiver();

    }

    @Override
    protected void onResume() {
        super.onResume();
        btnSwitch.setEnabled(true);
    }

    private void dispatchTakePictureIntent(){
        try {
            btnSwitch.setEnabled(false);
            startActivityIfNeeded(intentCamera,0);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initViews(){
        ivPreview = findViewById(R.id.ivPreview);
        tvGuess = findViewById(R.id.tvGuess);
        btnSwitch = findViewById(R.id.btnSwitch);

        btnSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakePictureIntent();
            }
        });
    }

    private void initIntents() {
        intentCamera = new Intent(this, CameraActivity.class);
        intentCamera.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
    }

    private void configureReceiver() {
        filter = new IntentFilter();
        filter.addAction(Constants.BROADCAST_KEY1);
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                presenter.runThroughNN(Constants.TEMP_IMG_KEY);
            }
        };
        receiverReg();
    }

    public void receiverReg(){
        registerReceiver(receiver,filter);
    }
    public void receiverUnreg(){
        unregisterReceiver(receiver);
    }

    @Override
    public void updateText(String text) {
        tvGuess.setText(text);
    }

    @Override
    public void updatePicture(String uri) {

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        receiverUnreg();
    }

}
